﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Logging;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;
using System;

namespace Maersk.Sorting.Api
{
    public class SortJobProcessor : ISortJobProcessor
    {
        private readonly ILogger<SortJobProcessor> _logger;

        public SortJobProcessor(ILogger<SortJobProcessor> logger)
        {
            _logger = logger;

            // initializing the Cache
            this.Cache.Set<List<SortJob>>("jobs", jobs);
        }

        public async Task<SortJob> Process(SortJob job)
        {
            _logger.LogInformation("Processing job with ID '{JobId}'.", job.Id);

            var stopwatch = Stopwatch.StartNew();

            var output = job.Input.OrderBy(n => n).ToArray();
            await Task.Delay(5000); // NOTE: This is just to simulate a more expensive operation

            var duration = stopwatch.Elapsed;

            _logger.LogInformation("Completed processing job with ID '{JobId}'. Duration: '{Duration}'.", job.Id, duration);

            return new SortJob(
                id: job.Id,
                status: SortJobStatus.Completed,
                duration: duration,
                input: job.Input,
                output: output);
        }

        List<SortJob> jobs = new List<SortJob>();

        // For Storage MemoryCache is being used, Redis or database also can be used.
        MemoryCache Cache = new MemoryCache(new MemoryCacheOptions());

        public void AppendJob(SortJob newJob)
        {
            newJob = Process(newJob).Result;

            jobs = this.Cache.Get<List<SortJob>>("jobs");
            jobs.Add(newJob);

            this.Cache.Set<List<SortJob>>("jobs", jobs);
        }

        public IList<SortJob> GetAllJobs()
        {
            return this.Cache.Get<List<SortJob>>("jobs");
        }

        public SortJob GetJob(Guid id)
        {
            jobs = this.Cache.Get<List<SortJob>>("jobs");
            return jobs.Where(x => x.Id == id).FirstOrDefault();
            
        }
    }
}
